import os
import requests

# -------------------------------
# Configuration
# -------------------------------

BASE_URL = "https://cdn.classicube.net/client/latest/assets/"
ASSETS_DIR = "assets"

# Folders to create
FOLDERS = ["blocks", "gui", "items", "textures", "sounds"]

# Files to download in each folder (expand as needed)
FILES = {
    "blocks": [
        "stone.png", "dirt.png", "grass.png", "sand.png", "wood.png",
        "cobblestone.png", "planks.png", "brick.png", "leaves.png"
    ],
    "gui": [
        "logo.png", "icons.png", "hotbar.png", "crosshair.png"
    ],
    "items": [
        "apple.png", "pickaxe.png", "sword.png", "shovel.png", "axe.png"
    ],
    "textures": [
        "cloud.png", "water.png", "lava.png", "sun.png", "moon.png"
    ],
    "sounds": [
        "click.wav", "step.wav", "place.wav", "break.wav", "jump.wav"
    ]
}

# -------------------------------
# Helper functions
# -------------------------------

def ensure_folders():
    for folder in FOLDERS:
        path = os.path.join(ASSETS_DIR, folder)
        os.makedirs(path, exist_ok=True)
        print(f"Folder ready: {path}")

def download_file(url, dest_path):
    try:
        r = requests.get(url, stream=True)
        if r.status_code == 200:
            with open(dest_path, "wb") as f:
                for chunk in r.iter_content(1024):
                    f.write(chunk)
            print(f"Downloaded: {dest_path}")
        else:
            print(f"Failed to download {url} (status {r.status_code})")
    except Exception as e:
        print(f"Error downloading {url}: {e}")

def download_all_files():
    for folder, file_list in FILES.items():
        for file_name in file_list:
            url = f"{BASE_URL}{folder}/{file_name}"
            dest = os.path.join(ASSETS_DIR, folder, file_name)
            download_file(url, dest)

# -------------------------------
# Main script
# -------------------------------

if __name__ == "__main__":
    print("Setting up Classicube offline assets...")
    ensure_folders()
    download_all_files()
    print("\nAll requested assets are downloaded and ready for offline use!")
