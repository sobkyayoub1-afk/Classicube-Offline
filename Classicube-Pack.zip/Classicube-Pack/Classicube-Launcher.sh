#!/bin/bash

# ===============================
# Classicube One-Click Launcher
# ===============================

DIR="/Users/ayoub/Classicube-Pack"
PORT=8080
PAGE="y.html"

cd "$DIR" || {
    echo "❌ Folder not found: $DIR"
    read -p "Press Enter to exit..."
    exit 1
}

# Detect Python
if command -v python3 >/dev/null 2>&1; then
    PYTHON=python3
elif command -v python >/dev/null 2>&1; then
    PYTHON=python
else
    echo "❌ Python is not installed."
    echo "👉 https://www.python.org"
    read -p "Press Enter to exit..."
    exit 1
fi

echo "✅ Using $PYTHON"
echo "📁 Serving from $DIR"
echo "🌐 Opening Classicube..."

# Open browser
sleep 1
open "http://localhost:$PORT/$PAGE"

# Start server
$PYTHON -m http.server $PORT
